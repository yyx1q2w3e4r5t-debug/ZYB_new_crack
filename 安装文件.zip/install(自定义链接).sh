#!/system/bin/sh

export LD_LIBRARY_PATH=/system/lib64:/system/lib:/vendor/lib64:/vendor/lib
export PATH=/system/bin:/system/xbin:/sbin:$PATH

log_info() { echo "[$(date '+%H:%M:%S')] [INFO] $*"; }
log_warn() { echo "[$(date '+%H:%M:%S')] [WARN] $*"; }
log_error() { echo "[$(date '+%H:%M:%S')] [ERROR] $*"; }

clear
echo "======================================================"
echo "   作业帮 IoT DEX注入一 自定义链接 "
echo "======================================================"
read -p "请输入 APK 的外网直链 (http/https): " APK_URL
if [ -z "$APK_URL" ]; then
    echo "[!] 链接不能为空，退出。"
    exit 1
fi

# 配置区
LOCAL_APK="/storage/emulated/0/hd.apk"
JSON_FILE="/storage/emulated/0/jc_broadcast.json"
PKG_NAME="JC.CODE.V3"
MSG_ID="$(date +%s)12345678"

log_info "=== 初始化：检查 DEX 文件 ==="
QPY_DIR1="/data/data/org.qpython.qpy3/files"
QPY_DIR2="/data/data/org.qpython.qpy/files"
FOUND_DEX=""

for dir in "$QPY_DIR1" "$QPY_DIR2"; do
    if [ -f "$dir/installer.dex" ]; then
        FOUND_DEX="$dir/installer.dex"
        log_info "  [-] 在私有目录找到 DEX: $FOUND_DEX"
        break
    fi
done

if [ -z "$FOUND_DEX" ]; then
    log_warn "  [!] 私有目录没有 DEX，尝试从外部存储复制..."
    if [ -f "/storage/emulated/0/installer.dex" ]; then
        SRC_DEX="/storage/emulated/0/installer.dex"
        for dir in "$QPY_DIR1" "$QPY_DIR2"; do
            if [ -d "$dir" ]; then
                cp "$SRC_DEX" "$dir/installer.dex" 2>/dev/null
                if [ -f "$dir/installer.dex" ]; then
                    FOUND_DEX="$dir/installer.dex"
                    log_info "  [-] 复制成功: $FOUND_DEX"
                    break
                fi
            fi
        done
        [ -z "$FOUND_DEX" ] && FOUND_DEX="$SRC_DEX"
    else
        log_error "  [!] 致命错误：未找到 installer.dex！"
        log_error "  [!] 请将 installer.dex 放到 /storage/emulated/0/ 或 QPython 私有目录。"
        exit 1
    fi
fi

DEX_PATH="$FOUND_DEX"
chmod 400 "$DEX_PATH" 2>/dev/null
log_info "  [-] 使用的 DEX 路径: $DEX_PATH"

log_info "=== JC Code 注入脚本 ==="
log_info "设备型号: $(getprop ro.product.model) | 系统版本: $(getprop ro.build.version.release)"
API_LEVEL=$(getprop ro.build.version.sdk)
log_info "API 级别 (SDK): $API_LEVEL"
if [ "$API_LEVEL" -ge 31 ]; then
    log_warn "  [!] 系统为 Android 12+"
fi

log_info "[阶段3] 强制重新下载 APK 以计算最新 MD5..."

rm -f "$LOCAL_APK"

if command -v curl >/dev/null 2>&1; then
    curl -k -L -o "$LOCAL_APK" "$APK_URL"
elif command -v wget >/dev/null 2>&1; then
    wget --no-check-certificate -O "$LOCAL_APK" "$APK_URL"
elif [ -f "/system/bin/curl" ]; then
    /system/bin/curl -k -L -o "$LOCAL_APK" "$APK_URL"
else
    log_error "  [!] 系统中未找到 curl 或 wget，无法下载！"
    exit 1
fi

if [ ! -s "$LOCAL_APK" ]; then
    log_error "  [!] APK 下载失败或文件为空！"
    exit 1
fi
log_info "  [-] 下载完成"

log_info "[阶段4] 计算 APK 真实 MD5..."
REAL_MD5=$(md5sum "$LOCAL_APK" 2>/dev/null | awk '{print $1}')
if [ -z "$REAL_MD5" ]; then
    REAL_MD5=$(toybox md5sum "$LOCAL_APK" 2>/dev/null | awk '{print $1}')
fi
if [ -z "$REAL_MD5" ]; then
    log_warn "  [!] 无法计算 MD5，使用硬编码值。"
    REAL_MD5="5fa3d1674b1a0ebbe4b6fba22185bfd3"
else
    log_info "  [-] 真实 MD5: $REAL_MD5"
fi

log_info "[阶段5] 生成 JSON Payload..."
cat > "$JSON_FILE" <<EOF
{"pkg_name":"com.zuoyebang.iot.pad.appstore","msg_id":"$MSG_ID","sub_type":3,"type":2,"data":{"advertisement":0,"advertisementLabel":"无","age":0,"ageLabel":"","apkMd5":"$REAL_MD5","apkName":"JC.CODE.V3","apkSize":32767,"apkSizeStr":"32767M","apkUrl":"$APK_URL","apkVersion":"3.1.0","apkVersionCode":20,"appIdThird":20,"browseWeb":0,"browseWebLabel":"无","changeLog":"Crack By KON-唯","containPayContent":1,"developer":"Crack By KON-唯","enName":"","entertainment":0,"entertainmentLabel":"无","extraThird":"SkNDb2RlVjM=","from":1,"icon":"https://www.birchua.cn/tb.png","icpNumber":"JC Code","id":2651,"isCtlWhite":0,"isGreenApp":1,"isMonitored":false,"isSensitive":0,"name":"JC Code V3","onShelf":1,"payContentLabel":"","permissions":null,"previewPics":null,"privacyLink":"https://www.birchua.cn","remark":"Crack By KON-唯","remoteInstallMsg":"安装 JC Code V3 中...（Crack By KON-唯）","risk":0,"statusInPad":0,"summary":"Crack By KON-唯","supervise":1,"tags":null,"type":1,"uploadTime":32767,"versionCodeThird":20}}
EOF
log_info "  [-] JSON 生成成功"


rm -f "$LOCAL_APK"

log_info "[阶段6] 探测系统服务..."
ZYB_SERVICE=$(service list 2>/dev/null | grep -i "zybos\|zuoyebang" | head -n 1 | awk '{print $1}' | cut -d: -f1)
if [ -z "$ZYB_SERVICE" ]; then
    log_warn "  [!] 未扫描到明确服务，使用默认名 zybos_manager"
    ZYB_SERVICE="zybos_manager"
else
    log_info "  [-] 探测到潜在目标服务: $ZYB_SERVICE"
fi
service call "$ZYB_SERVICE" 6 i32 0 2>&1

log_info "[阶段7] 执行 app_process 注入..."
log_info "  命令: CLASSPATH=$DEX_PATH /system/bin/app_process /system/bin RemoteInstaller $JSON_FILE $PKG_NAME"
OUTPUT_LOG="/storage/emulated/0/app_process_debug.log"

CLASSPATH="$DEX_PATH" /system/bin/app_process /system/bin RemoteInstaller "$JSON_FILE" "$PKG_NAME" > "$OUTPUT_LOG" 2>&1
EXIT_CODE=$?

if [ -f "$OUTPUT_LOG" ]; then
    log_info "  [--- 注入输出开始 ---]"
    while IFS= read -r line; do echo "  $line"; done < "$OUTPUT_LOG"
    log_info "  [--- 注入输出结束 ---]"
fi

if [ $EXIT_CODE -eq 0 ]; then
    log_info "  [-] app_process 执行成功。"
elif [ $EXIT_CODE -eq 139 ]; then
    log_error "  [!] 崩溃: 触发段错误 (Signal 11) core dumped。"
elif [ $EXIT_CODE -eq 134 ]; then
    log_error "  [!] 崩溃: 触发 Abort (Signal 6) 或 DEX 权限拒绝 (返回码 134)。"
else
    log_error "  [!] 异常退出，返回码: $EXIT_CODE"
fi

echo "====================================================================="
log_info "=== 脚本执行结束 ==="